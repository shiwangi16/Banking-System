import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'EMI Calculator';
  principalAmount: number =  0;
  rateOfInterest: number = 0;
  tenure: number = 0;
  emi: number = 0;
  calculate_emi () {
    var outstandingAmount = Number(this.principalAmount) + Number(this.principalAmount * (this.rateOfInterest / 100) * this.tenure);
    this.emi = outstandingAmount / this.tenure;
  }
}
